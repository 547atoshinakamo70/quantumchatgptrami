def prove(statement: dict, witness: dict) -> dict:
    # TODO: replace with your real prover (circom/snarkjs/halo2/etc.)
    return {"proof": "stub", "public": statement}

def verify(statement: dict, proof: dict) -> bool:
    # TODO: replace with your real verifier
    return bool(proof)
