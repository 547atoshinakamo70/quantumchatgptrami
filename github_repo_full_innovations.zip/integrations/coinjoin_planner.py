def plan_coinjoin(utxos, targets, policy=None):
    # TODO: replace with your coinjoin algorithm (BnB/heuristics/policies)
    return {"rounds": [], "note": "stub planner"}
